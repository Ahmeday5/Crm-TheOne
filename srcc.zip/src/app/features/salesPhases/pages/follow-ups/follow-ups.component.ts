import { Component } from '@angular/core';

@Component({
  selector: 'app-follow-ups',
  standalone: true,
  imports: [],
  templateUrl: './follow-ups.component.html',
  styleUrl: './follow-ups.component.scss'
})
export class FollowUpsComponent {

}
