import { Component } from '@angular/core';

@Component({
  selector: 'app-contracts',
  standalone: true,
  imports: [],
  templateUrl: './contracts.component.html',
  styleUrl: './contracts.component.scss'
})
export class ContractsComponent {

}
