import { Component } from '@angular/core';

@Component({
  selector: 'app-price-offers',
  standalone: true,
  imports: [],
  templateUrl: './price-offers.component.html',
  styleUrl: './price-offers.component.scss'
})
export class PriceOffersComponent {

}
