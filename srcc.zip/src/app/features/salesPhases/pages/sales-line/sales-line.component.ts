import { Component } from '@angular/core';

@Component({
  selector: 'app-sales-line',
  standalone: true,
  imports: [],
  templateUrl: './sales-line.component.html',
  styleUrl: './sales-line.component.scss'
})
export class SalesLineComponent {

}
