import { Component } from '@angular/core';

@Component({
  selector: 'app-appsupport-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './appsupport-dashboard.component.html',
  styleUrl: './appsupport-dashboard.component.scss'
})

export class AppsupportDashboardComponent {

}
